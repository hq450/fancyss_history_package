#!/bin/sh
export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
source $KSROOT/bin/helper.sh
eval `dbus export brook_`
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
lan_ipaddr=`uci get network.lan.ipaddr`
ip_prefix_hex=`echo $lan_ipaddr | awk -F "." '{printf ("0x%02x", $1)} {printf ("%02x", $2)} {printf ("%02x", $3)} {printf ("00/0xffffff00")}'`
LOCK_FILE=/var/lock/brook.lock
LOG_FILE=/tmp/upload/brook_log.txt
IFIP=`echo $brook_basic_server|grep -E "([0-9]{1,3}[\.]){3}[0-9]{1,3}|:"`
ISP_DNS1=`cat /tmp/resolv.conf.auto|cut -d " " -f 2|grep -v 0.0.0.0|grep -v 127.0.0.1|sed -n 2p`
ISP_DNS2=`cat /tmp/resolv.conf.auto|cut -d " " -f 2|grep -v 0.0.0.0|grep -v 127.0.0.1|sed -n 3p`

create_dnsmasq_conf(){
	local CDN IFIP_DNS
	IFIP_DNS=`echo $ISP_DNS1|grep -E "([0-9]{1,3}[\.]){3}[0-9]{1,3}|:"`
	[ -n "$IFIP_DNS" ] && CDN="$ISP_DNS1" || CDN="114.114.114.114"
	[ "$brook_dns_china" == "2" ] && CDN="223.5.5.5"
	[ "$brook_dns_china" == "3" ] && CDN="223.6.6.6"
	[ "$brook_dns_china" == "4" ] && CDN="114.114.114.114"
	[ "$brook_dns_china" == "5" ] && CDN="114.114.115.115"
	[ "$brook_dns_china" == "6" ] && CDN="1.2.4.8"
	[ "$brook_dns_china" == "7" ] && CDN="210.2.4.8"
	[ "$brook_dns_china" == "8" ] && CDN="112.124.47.27"
	[ "$brook_dns_china" == "9" ] && CDN="114.215.126.16"
	[ "$brook_dns_china" == "10" ] && CDN="180.76.76.76"
	[ "$brook_dns_china" == "11" ] && CDN="119.29.29.29"
	[ "$brook_dns_china" == "12" ] && CDN="$brook_dns_china_user"

	# append china site
	[ ! -f /tmp/dnsmasq.d/brookcdn.conf ] && {
		echo_date 创建国内CDN解析优化配置文件
		cat $KSROOT/brook/cdn.txt | sed "s/^/server=&\/./g" | sed "s/$/\/&$CDN/g" | sort | awk '{if ($0!=line) print;line=$0}' > /tmp/dnsmasq.d/brookcdn.conf
	}
	[ ! -f /tmp/dnsmasq.d/brookgfw.conf ] && {
		echo_date 创建国外GFW解析优化配置文件
		cat $KSROOT/brook/gfwlist.txt | awk '{print "server=/"$1"/127.0.0.1#7953\nipset=/"$1"/black_list"}' >> /tmp/dnsmasq.d/brookgfw.conf
	}		
	
	rm -rf /tmp/dnsmasq.d/brookcustom.conf
	if [ -n "$brook_dnsmasq" ];then
		echo_date 添加自定义dnsmasq设置到/tmp/dnsmasq.d/brookcustom.conf
		echo "$brook_dnsmasq" | base64_decode | sort -u >> /tmp/dnsmasq.d/brookcustom.conf
	fi

	[ ! -f "/tmp/dnsmasq.d/brookroute.conf" ] && {
		echo_date 创建状态检测解析优化配置文件
		cat > /tmp/dnsmasq.d/brookroute.conf <<-EOF
			#for router itself
			server=/.google.com.tw/127.0.0.1#7953
			ipset=/.google.com.tw/router
			server=/.google.com.ncr/127.0.0.1#7953
			ipset=/.google.com.ncr/router
			server=/.github.com/127.0.0.1#7953
			ipset=/.github.com/router
			server=/.github.io/127.0.0.1#7953
			ipset=/.github.io/router
			server=/.raw.githubusercontent.com/127.0.0.1#7953
			ipset=/.raw.githubusercontent.com/router
			server=/.apnic.net/127.0.0.1#7953
			ipset=/.apnic.net/router
		EOF
	}
	# append white domain list,not through ss
	wanwhitedomain=$(echo $brook_wan_white_domain | base64_decode)
	if [ -n "$brook_wan_white_domain" ];then
		echo_date 应用域名白名单
		echo "#for white_domain" >> /tmp/dnsmasq.d/brookwblist.conf
		for wan_white_domain in $wanwhitedomain
		do 
			echo "$wan_white_domain" | sed "s/^/server=&\/./g" | sed "s/$/\/$CDN#53/g" >> /tmp/dnsmasq.d/brookwblist.conf
			echo "$wan_white_domain" | sed "s/^/ipset=&\/./g" | sed "s/$/\/white_list/g" >> /tmp/dnsmasq.d/brookwblist.conf
		done
	fi
	# apple 和microsoft不能走ss
	echo "#for special site" >> /tmp/dnsmasq.d/brookwblist.conf
	for wan_white_domain2 in "apple.com" "microsoft.com"
	do 
		echo "$wan_white_domain2" | sed "s/^/server=&\/./g" | sed "s/$/\/$CDN#53/g" >> /tmp/dnsmasq.d/brookwblist.conf
		echo "$wan_white_domain2" | sed "s/^/ipset=&\/./g" | sed "s/$/\/white_list/g" >> /tmp/dnsmasq.d/brookwblist.conf
	done
	
	# append black domain list,through ss
	wanblackdomain=$(echo $brook_wan_black_domain | base64_decode)
	if [ -n "$brook_wan_black_domain" ];then
		echo_date 应用域名黑名单
		echo "#for black_domain" >> /tmp/dnsmasq.d/brookwblist.conf
		for wan_black_domain in $wanblackdomain
		do 
			echo "$wan_black_domain" | sed "s/^/server=&\/./g" | sed "s/$/\/127.0.0.1#7953/g" >> /tmp/dnsmasq.d/brookwblist.conf
			echo "$wan_black_domain" | sed "s/^/ipset=&\/./g" | sed "s/$/\/black_list/g" >> /tmp/dnsmasq.d/brookwblist.conf
		done
	fi
	# ln conf
	
	if [ "$brook_dns_china" == "1" ];then
		IFIP_DNS1=`echo $ISP_DNS1|grep -E "([0-9]{1,3}[\.]){3}[0-9]{1,3}|:"`
		IFIP_DNS2=`echo $ISP_DNS2|grep -E "([0-9]{1,3}[\.]){3}[0-9]{1,3}|:"`
		[ -n "$IFIP_DNS1" ] && CDN1="$ISP_DNS1" || CDN1="114.114.114.114"
		[ -n "$IFIP_DNS2" ] && CDN2="$ISP_DNS2" || CDN2="114.114.115.115"
	fi
	
	echo "no-resolv" >> /tmp/dnsmasq.d/brook.conf
	echo "all-servers" >> /tmp/dnsmasq.d/brook.conf
	if [ "$brook_dns_plan" == "1" ] || [ -z "$brook_dns_china" ];then
		if [ "$brook_dns_china" == "1" ];then
			echo_date DNS解析方案国内优先，使用运营商DNS优先解析国内DNS.
			echo "server=$CDN1#53" >> /tmp/dnsmasq.d/brook.conf
			echo "server=$CDN2#53" >> /tmp/dnsmasq.d/brook.conf
		else
			echo_date DNS解析方案国内优先，使用自定义DNS：$CDN进行解析国内DNS.
			echo "server=$CDN1#53" >> /tmp/dnsmasq.d/brook.conf
		fi
	elif [ "$brook_dns_plan" == "2" ];then
		echo_date DNS解析方案国外优先，优先解析国外DNS.
		echo "server=127.0.0.1#7953" >> /tmp/dnsmasq.d/brook.conf
	fi
}

create_redsocks_conf(){
	local KDF
	[ "$brook_dns_foreign" == "1" ] && KDF="208.67.220.220"
	[ "$brook_dns_foreign" == "2" ] && KDF="8.8.8.8"
	[ "$brook_dns_foreign" == "3" ] && KDF="8.8.4.4"
	[ "$brook_dns_foreign" == "4" ] && KDF="$brook_dns_foreign_user"	
	cat > /tmp/etc/redsock2.conf <<-EOF
		base {
		  log_debug = off;
		  log_info = off;
		  daemon = on;
		  redirector= iptables;
		}

		redsocks {
		  local_ip = $lan_ipaddr;
		  local_port = 1280;
		  ip = 127.0.0.1;
		  port = 1281;
		  type = socks5;
		  autoproxy = 0;
		  timeout = 10;
		}
		
		redudp {
		  local_ip = $lan_ipaddr;
		  local_port = 1280;
		  ip = 127.0.0.1;
		  port = 1281;
		  type = socks5;
		  dest_ip = $KDF;
		  dest_port = 53;
		  udp_timeout = 30;
		}
	EOF
	cat > /tmp/etc/dnsforwarder.conf <<-EOF
		LogOn false
		UDPLocal 127.0.0.1:7953
		TCPGroup $KDF,8.8.4.4 * 127.0.0.1:1281
		BlockIP 243.185.187.39,46.82.174.68,37.61.54.158,93.46.8.89,59.24.3.173,203.98.7.65,8.7.198.45,78.16.49.15,159.106.121.75
		BlockNegativeResponse false
		UseCache false
		ReloadCache false
		OverwriteCache false
		StatisticUpdateInterval 29
	EOF
}

restore_dnsmasq_conf(){
	echo_date 删除 brook 相关的名单配置文件.
	# remove conf under /jffs/etc/dnsmasq.d
	rm -rf /tmp/dnsmasq.d/brook*.conf
}

restore_start_file(){
	echo_date 清除firewall中相关的 brook 启动命令...
	uci -q batch <<-EOT
	  delete firewall.ks_brook
	  commit firewall
	EOT
}

restore_start_file(){
	echo_date 清除firewall中相关的 brook 启动命令...
	uci -q batch <<-EOT
	  delete firewall.ks_brook
	  commit firewall
	EOT
}

kill_process(){
	local brook redsocks dnsforwarder
	#--------------------------------------------------------------------------
	brook=$(ps | grep "brook" | grep -v "grep")
	redsocks=$(ps | grep "redsocks2" | grep -v "grep")
	dnsforwarder=$(ps | grep "dnsforwarder" | grep -v "grep")
	# kill brook
	if [ -n "$brook" ]; then 
		echo_date 关闭 brook 进程...
		killall brook >/dev/null 2>&1
	fi
	# kill redsocks2
	if [ -n "$redsocks" ]; then 
		echo_date 关闭 redsocks2 进程...
		killall redsocks2 >/dev/null 2>&1
	fi
	# kill dnsforwarder
	if [ -n "$dnsforwarder" ]; then 
		echo_date 关闭 dnsforwarder 进程...
		killall dnsforwarder >/dev/null 2>&1
	fi
}

# ==========================================================================================
# try to resolv the brook server ip if it is domain...
resolv_server_ip(){
	if [ -z "$IFIP" ];then
		echo_date 使用nslookup方式解析 brook 的ip地址
			server_ip=`nslookup "$brook_basic_server" 114.114.114.114 | sed '1,4d' | awk '{print $3}' | grep -v :|awk 'NR==1{print}'`

		if [ -n "$server_ip" ];then
			echo_date  brook 服务器ip地址解析成功：$server_ip.
			brook_basic_server="$server_ip"
			brook_basic_server_ip="$server_ip"
		else
			# get pre-resoved ip in skipd
			brook_basic_server=`dbus get brook_basic_server`
			echo_date  brook 的ip地址解析失败，将由brook自己解析.
		fi
	else
		echo_date 检测到你的 brook 服务器地址已经是IP格式：$brook_basic_server,跳过解析... 
		brook_basic_server_ip="$brook_basic_server"
	fi
}

#--------------------------------------------------------------------------------------
auto_start(){
	# nat start
	echo_date 添加nat-start触发事件...
	uci -q batch <<-EOT
	  delete firewall.ks_shadowsocks
	  set firewall.ks_brook=include
	  set firewall.ks_brook.type=script
	  set firewall.ks_brook.path=/koolshare/scripts/brook_config.sh
	  set firewall.ks_brook.family=any
	  set firewall.ks_brook.reload=1
	  commit firewall
	EOT

	# auto start
	[ ! -L "/etc/rc.d/S98brook.sh" ] && ln -sf $KSROOT/init.d/S98brook.sh /etc/rc.d/S98brook.sh
}

#=======================================================================================
get_socks_chain() {
	case "$1" in
		0)
			echo "127.0.0.1"
		;;
		1)
			echo "0.0.0.0"
		;;
	esac
}

start_brook(){
	echo_date 开启 brook 主进程...
	brook client -l $(get_socks_chain $brook_basic_sock):1281 -i $(get_socks_chain $brook_basic_sock) -s $brook_basic_server:$brook_basic_port -p $brook_basic_password&
	echo_date 开启 redsocks2 主进程...
	create_redsocks_conf
	redsocks2 -c /tmp/etc/redsock2.conf
	echo_date 开启 dnsforwarder 主进程...
	dnsforwarder -f /tmp/etc/dnsforwarder.conf -d >/dev/null 2>&1
}

# =======================================================================================================
flush_nat(){
	echo_date 尝试先清除已存在的iptables规则，防止重复添加
	# flush rules and set if any
	iptables -t nat -D PREROUTING -p tcp -j BROOK >/dev/null 2>&1
	sleep 1
	iptables -t nat -F BROOK > /dev/null 2>&1 && iptables -t nat -X BROOK > /dev/null 2>&1
	iptables -t nat -F BROOK_EXT > /dev/null 2>&1
	iptables -t nat -F BROOK_GFW > /dev/null 2>&1 && iptables -t nat -X BROOK_GFW > /dev/null 2>&1
	iptables -t nat -F BROOK_CHN > /dev/null 2>&1 && iptables -t nat -X BROOK_CHN > /dev/null 2>&1
	iptables -t nat -F BROOK_GLO > /dev/null 2>&1 && iptables -t nat -X BROOK_GLO > /dev/null 2>&1
	iptables -t mangle -D PREROUTING -p udp -j BROOK >/dev/null 2>&1
	iptables -t mangle -F BROOK >/dev/null 2>&1 && iptables -t mangle -X BROOK >/dev/null 2>&1
	iptables -t mangle -F BROOK_CHN > /dev/null 2>&1 && iptables -t mangle -X BROOK_CHN > /dev/null 2>&1
	iptables -t nat -D OUTPUT -p tcp -m set --match-set router dst -j REDIRECT --to-ports 1280 >/dev/null 2>&1
	iptables -t nat -F OUTPUT > /dev/null 2>&1
	iptables -t nat -X BROOK_EXT > /dev/null 2>&1
	
	kp_mode=`/koolshare/bin/dbus get koolproxy_mode`
	kp_enable=`iptables -t nat -L PREROUTING | grep KOOLPROXY |wc -l`
	chromecast_nu=`iptables -t nat -L PREROUTING -v -n --line-numbers|grep "dpt:53"|awk '{print $1}'`
	if [ "$kp_mode" != "2" ] || [ "$kp_enable" -eq 0 ]; then
		iptables -t nat -D PREROUTING $chromecast_nu >/dev/null 2>&1
	fi

	#flush_ipset
	echo_date 先清空已存在的ipset名单，防止重复添加
	ipset -F white_list >/dev/null 2>&1 && ipset -X white_list >/dev/null 2>&1
	ipset -F black_list >/dev/null 2>&1 && ipset -X black_list >/dev/null 2>&1
	ipset -F gfwlist >/dev/null 2>&1 && ipset -X gfwlist >/dev/null 2>&1
	ipset -F router >/dev/null 2>&1 && ipset -X router >/dev/null 2>&1

	#remove_redundant_rule
	ip_rule_exist=`ip rule show | grep "fwmark 0x1/0x1 lookup 310" | grep -c 310`
	if [ ! -z "ip_rule_exist" ];then
		echo_date 清除重复的ip rule规则.
		until [ "$ip_rule_exist" = 0 ]
		do 
			#ip rule del fwmark 0x07 table 310
			ip rule del fwmark 0x07 table 310 pref 789
			ip_rule_exist=`expr $ip_rule_exist - 1`
		done
	fi

	# remove_route_table
	echo_date 删除ip route规则.
	ip route del local 0.0.0.0/0 dev lo table 310 >/dev/null 2>&1
}

# creat ipset rules
creat_ipset(){
	echo_date 创建ipset名单
	ipset -! create white_list nethash && ipset flush white_list
	ipset -! create black_list nethash && ipset flush black_list
	ipset -! create router nethash && ipset flush router
}

add_white_black_ip(){
	# black ip/cidr
	ip_tg="149.154.0.0/16 91.108.4.0/22 91.108.56.0/24 109.239.140.0/24 67.198.55.0/24"
	for ip in $ip_tg
	do
		ipset -! add black_list $ip >/dev/null 2>&1
	done
	
	if [ ! -z $brook_wan_black_ip ];then
		brook_wan_black_ip=`dbus get brook_wan_black_ip|base64_decode|sed '/\#/d'`
		echo_date 应用IP/CIDR黑名单
		for ip in $brook_wan_black_ip
		do
			ipset -! add black_list $ip >/dev/null 2>&1
		done
	fi
	
	# white ip/cidr
	#ip1=$(nvram get wan0_ipaddr | cut -d"." -f1,2)
	ip1=`cat /etc/config/pppoe|grep localip | awk '{print $4}'| cut -d"." -f1,2`
	[ ! -z "$brook_basic_server_ip" ] && SERVER_IP=$brook_basic_server_ip || SERVER_IP=""
	ip_lan="0.0.0.0/8 10.0.0.0/8 100.64.0.0/10 127.0.0.0/8 169.254.0.0/16 172.16.0.0/12 192.168.0.0/16 224.0.0.0/4 240.0.0.0/4 $ip1.0.0/16 $SERVER_IP 223.5.5.5 223.6.6.6 114.114.114.114 114.114.115.115 1.2.4.8 210.2.4.8 112.124.47.27 114.215.126.16 180.76.76.76 119.29.29.29 $ISP_DNS1 $ISP_DNS2"
	for ip in $ip_lan
	do
		ipset -! add white_list $ip >/dev/null 2>&1
	done
	
	if [ ! -z $brook_wan_white_ip ];then
		brook_wan_white_ip=`echo $brook_wan_white_ip|base64_decode|sed '/\#/d'`
		echo_date 应用IP/CIDR白名单
		for ip in $brook_wan_white_ip
		do
			ipset -! add white_list $ip >/dev/null 2>&1
		done
	fi
}

get_action_chain() {
	case "$1" in
		0)
			echo "RETURN"
		;;
		1)
			echo "BROOK_GFW"
		;;
		2)
			echo "BROOK_CHN"
		;;
		3)
			echo "BROOK_GLO"
		;;
	esac
}

get_mode_name() {
	case "$1" in
		0)
			echo "不通过SS"
		;;
		1)
			echo "gfwlist模式"
		;;
		2)
			echo "大陆白名单模式"
		;;
		3)
			echo "全局模式"
		;;
	esac
}

factor(){
	if [ -z "$1" ] || [ -z "$2" ]; then
		echo ""
	else
		echo "$2 $1"
	fi
}

get_jump_mode(){
	case "$1" in
		0)
			echo "j"
		;;
		*)
			echo "g"
		;;
	esac
}

lan_acess_control(){
	# lan access control
	acl_nu=`dbus list brook_acl_mode|sort -n -t "=" -k 2|cut -d "=" -f 1 | cut -d "_" -f 4`
	if [ -n "$acl_nu" ]; then
		for acl in $acl_nu
		do
			ipaddr=`dbus get brook_acl_ip_$acl`
			ipaddr_hex=`dbus get brook_acl_ip_$acl | awk -F "." '{printf ("0x%02x", $1)} {printf ("%02x", $2)} {printf ("%02x", $3)} {printf ("%02x\n", $4)}'`
			proxy_mode=`dbus get brook_acl_mode_$acl`
			proxy_name=`dbus get brook_acl_name_$acl`
			mac=`dbus get brook_acl_mac_$acl`

			[ -n "$ipaddr" ] && [ -z "$mac" ] && echo_date 加载ACL规则：【$ipaddr】模式为：$(get_mode_name $proxy_mode)
			[ -z "$ipaddr" ] && [ -n "$mac" ] && echo_date 加载ACL规则：【$mac】模式为：$(get_mode_name $proxy_mode)
			[ -n "$ipaddr" ] && [ -n "$mac" ] && echo_date 加载ACL规则：【$ipaddr】【$mac】模式为：$(get_mode_name $proxy_mode)
			# acl in brook
			iptables -t nat -A BROOK $(factor $ipaddr "-s") -p tcp -$(get_jump_mode $proxy_mode) $(get_action_chain $proxy_mode)
			# acl in OUTPUT（used by koolproxy）
			iptables -t nat -A BROOK_EXT -p tcp  -m mark --mark "$ipaddr_hex" -$(get_jump_mode $proxy_mode) $(get_action_chain $proxy_mode)
			# acl magic happens here
			iptables -t mangle -A BROOK $(factor $ipaddr "-s") $(factor $mac "-m mac --mac-source") -p udp -$(get_jump_mode $proxy_mode) $(get_action_chain $proxy_mode)
		done
		echo_date 加载ACL规则：其余主机模式为：$(get_mode_name $brook_acl_default_mode)
	else
		#brook_acl_default_mode="1"
		echo_date 加载ACL规则：所有模式为：$(get_mode_name $brook_acl_default_mode)
	fi
}

apply_nat_rules(){
	#----------------------BASIC RULES---------------------
	echo_date 写入iptables规则到nat表中...
	# 创建BROOK nat rule
	iptables -t nat -N BROOK
	# 扩展
	iptables -t nat -N BROOK_EXT
	# IP/cidr/白域名 白名单控制（不走ss） for BROOK
	iptables -t nat -A BROOK -p tcp -m set --match-set white_list dst -j RETURN
	# IP/cidr/白域名 白名单控制（不走ss） for BROOK_EXT
	iptables -t nat -A BROOK_EXT -p tcp -m set --match-set white_list dst -j RETURN
	#-----------------------FOR GFWLIST---------------------
	# 创建gfwlist模式nat rule
	iptables -t nat -N BROOK_GFW
	# IP/CIDR/黑域名 黑名单控制（走ss）
	iptables -t nat -A BROOK_GFW -p tcp -m set --match-set black_list dst -j REDIRECT --to-ports 1280
	# IP黑名单控制-gfwlist（走ss）
	iptables -t nat -A BROOK_GFW -p tcp -m set --match-set gfwlist dst -j REDIRECT --to-ports 1280
	#-----------------------FOR GLOABLE---------------------
	# 创建gfwlist模式nat rule
	iptables -t nat -N BROOK_GLO
	# IP黑名单控制-gfwlist（走ss）
	iptables -t nat -A BROOK_GLO -p tcp -j REDIRECT --to-ports 1280
	
	#-----------------------FOR CHN---------------------
	# 创建大陆白名单模式nat rule
	iptables -t nat -N BROOK_CHN
	# IP/CIDR/域名 黑名单控制（走ss）
	iptables -t nat -A BROOK_CHN -p tcp -m set --match-set black_list dst -j REDIRECT --to-ports 1280
	# cidr黑名单控制-chnroute（走ss）
	iptables -t nat -A BROOK_CHN -p tcp -m geoip ! --destination-country CN -j REDIRECT --to-ports 1280
	#load_tproxy
	ip rule add fwmark 0x07 table 310 pref 789
	ip route add local 0.0.0.0/0 dev lo table 310
	# 创建游戏模式udp rule
	iptables -t mangle -N BROOK
	# IP/cidr/白域名 白名单控制（不走ss）
	iptables -t mangle -A BROOK -p udp -m set --match-set white_list dst -j RETURN
	# 创建游戏模式udp rule
	iptables -t mangle -N BROOK_CHN
	# IP/CIDR/域名 黑名单控制（走ss）
	iptables -t mangle -A BROOK_CHN -p udp -m set --match-set black_list dst -j TPROXY --on-port 1280 --tproxy-mark 0x07
	# cidr黑名单控制-chnroute（走ss）
	iptables -t mangle -A BROOK_CHN -p udp -m geoip ! --destination-country CN -j TPROXY --on-port 1280 --tproxy-mark 0x07
	#-------------------------------------------------------
	# 局域网黑名单（不走ss）/局域网黑名单（走ss）
	lan_acess_control
	#-----------------------FOR ROUTER---------------------
	# router itself
	iptables -t nat -A OUTPUT -p tcp -m set --match-set router dst -j REDIRECT --to-ports 1280
	iptables -t nat -A OUTPUT -p tcp -m mark --mark $ip_prefix_hex -j BROOK_EXT
	
	# 把最后剩余流量重定向到相应模式的nat表中对对应的主模式的链
	
	iptables -t nat -A BROOK -p tcp $(factor $ss_acl_default_port "-m multiport --dport") -j $(get_action_chain $brook_acl_default_mode)
	# iptables -t nat -A OUTPUT -p tcp $(factor $ss_acl_default_port "-m multiport --dport") -m ttl --ttl-eq 160 -j $(get_action_chain $brook_acl_default_mode)
	iptables -t nat -A BROOK_EXT -p tcp $(factor $ss_acl_default_port "-m multiport --dport") -j $(get_action_chain $brook_acl_default_mode)
	# 如果是主模式游戏模式，则把BROOK链中剩余udp流量转发给BROOK_GLO链
	# 如果主模式不是游戏模式，则不需要把BROOK链中剩余udp流量转发给BROOK_GLO，不然会造成其他模式主机的udp也走游戏模式
	[ "$brook_acl_default_mode" == "2" ] && iptables -t mangle -A BROOK -p udp -j $(get_action_chain $brook_acl_default_mode)
	# 重定所有流量到 BROOK
	KP_INDEX=`iptables -t nat -L PREROUTING|tail -n +3|sed -n -e '/^KOOLPROXY/='`
	if [ -n "$KP_INDEX" ]; then
		let KP_INDEX+=1
		#确保添加到KOOLPROXY规则之后
		iptables -t nat -I PREROUTING $KP_INDEX -p tcp -j BROOK
	else
		PR_INDEX=`iptables -t nat -L PREROUTING|tail -n +3|sed -n -e '/^prerouting_rule/='`|| 1
		#如果kp没有运行，确保添加到prerouting_rule规则之后
		let PR_INDEX+=1	
		iptables -t nat -I PREROUTING $PR_INDEX -p tcp -j BROOK
	fi
	iptables -t mangle -I PREROUTING 1 -p udp -j BROOK
}

chromecast(){
	LOG1=开启chromecast功能（DNS劫持功能）
	chromecast_nu=`iptables -t nat -L PREROUTING -v -n --line-numbers|grep "dpt:53"|awk '{print $1}'`
	is_right_lanip=`iptables -t nat -L PREROUTING -v -n --line-numbers|grep "dpt:53" |grep "$lan_ipaddr"`
	
	if [ -z "$chromecast_nu" ]; then
		iptables -t nat -A PREROUTING -p udp --dport 53 -j DNAT --to $lan_ipaddr >/dev/null 2>&1
		echo_date $LOG1
	else
		if [ -z "$is_right_lanip" ]; then
			echo_date 黑名单模式开启DNS劫持
			iptables -t nat -D PREROUTING $chromecast_nu >/dev/null 2>&1
			iptables -t nat -A PREROUTING -p udp --dport 53 -j DNAT --to $lan_ipaddr >/dev/null 2>&1
		else
			echo_date DNS劫持规则已经添加，跳过~
		fi
	fi
}
# =======================================================================================================
load_nat(){
	echo_date "加载nat规则!"
	flush_nat
	creat_ipset
	add_white_black_ip
	apply_nat_rules
	chromecast
}

restart_dnsmasq(){
	# Restart dnsmasq
	echo_date 重启dnsmasq服务...
	/etc/init.d/dnsmasq restart >/dev/null 2>&1
}

detect_ss(){
	SS_NU=`iptables -nvL PREROUTING -t nat |sed 1,2d | sed -n '/SHADOWSOCKS/='` 2>/dev/null
	if [ -n "$SS_NU" ];then
		echo_date 检测到你开启了SS！！！
		echo_date brook不能和SS混用，请关闭SS后启用本插件！！
		echo_date 退出 brook 启动...
		dbus set brook_basic_enable=0
		echo_date ------------------------- brook 退出启动 -------------------------
		sleep 5
		echo XU6J03M6
		http_response "brook 和 SS不能同时开启！"
		sleep 1
		exit 1
	else
		echo_date brook符合启动条件！~
	fi
}

check_update_brook(){
	local lastver oldver
	echo_date 开始检查 brook 最新版本。。。
	lastver=$(wget --no-check-certificate --timeout=8 --tries=2 -qO- "https://github.com/txthinking/brook/tags"| grep "/txthinking/brook/releases/tag/"| head -n 1| awk -F "/tag/" '{print $2}'| sed 's/\">//') 
	oldver="v$(brook -v |cut -d" " -f3)"
	if [ -n "$lastver" ]; then 
		echo_date 当前版本：$oldver
		echo_date 最新版本：$lastver
		if [ "$lastver" == "$oldver" ]; then
			echo_date 当前已经是最新版本！
			dbus set brook_basic_version=$lastver
			sleep 3
			echo XU6J03M6
		else
			wget --no-check-certificate --timeout=8 --tries=2 -O - "https://github.com/txthinking/brook/releases/download/${lastver}/brook" > /tmp/brook
			if [ "$?" -eq 0 ] ; then
				echo_date "最新版本已下载，准备安装"
				kill_process
				mv /tmp/brook $KSROOT/bin/brook
				echo_date "最新版本已安装，准备重启插件"
				dbus set brook_basic_version=$lastver
				restart_brook
			else
				echo_date "最新版本下载失败，请检查网络到github的连通后再试！"
				dbus set brook_basic_version=$oldver
				sleep 3
				echo XU6J03M6
			fi
		fi
	else
		echo_date 最新版本号检查失败，请检查网络到github的连通后再试！
		sleep 3
		echo XU6J03M6
	fi	
}


restart_brook(){
	# router is on boot
	ONSTART=`ps -l|grep $PPID|grep -v grep|grep S98brook`
	# used by web for start/restart; or by system for startup by S98brook.sh in rc.d
	while [ -f "$LOCK_FILE" ]; do
		sleep 1
	done
	echo_date ---------------------- LEDE 固件 brook -----------------------
	detect_ss
	# stop first
	restore_dnsmasq_conf
	[ -z "$IFIP" ] && [ -z "$ONSTART" ] && restart_dnsmasq
	flush_nat
	restore_start_file
	kill_process
	echo_date ---------------------------------------------------------------------------------------
	[ -f "$LOCK_FILE" ] && return 1
	touch "$LOCK_FILE"
	# start
	resolv_server_ip
	[ -z "$ONSTART" ] && creat_game2_json
	create_dnsmasq_conf
	auto_start
	start_brook
	load_nat
	restart_dnsmasq
	echo_date ------------------------- brook 启动完毕 -------------------------
	# get_status >> /tmp/brook_start.txt
	# do not start by nat when start up
	[ ! -f "/tmp/brook.nat_lock" ] && touch /tmp/brook.nat_lock
	rm -f "$LOCK_FILE"
	return 0
}
stop_brook(){
	#only used by web stop
	while [ -f "$LOCK_FILE" ]; do
		sleep 1
	done
	echo_date ---------------------- LEDE 固件 brook -----------------------
	restore_dnsmasq_conf
	restart_dnsmasq
	flush_nat
	restore_start_file
	kill_process
	echo_date ------------------------- brook 成功关闭 -------------------------
}
restart_by_nat(){
	# for nat
	[ ! -f "/tmp/brook.nat_lock" ] && exit 0
	while [ -f "$LOCK_FILE" ]; do
		sleep 1
	done
	detect_ss
	restore_dnsmasq_conf
	kill_process
	load_nat
	start_brook
	create_dnsmasq_conf
	restart_dnsmasq
}

# used by rc.d
case $1 in
start)
	if [ "$brook_basic_enable" == "1" ];then
		restart_brook
	else
		stop_brook
    fi
	;;
stop)
	stop_brook
	;;
*)
	[ -z "$2" ] && restart_by_nat
	;;
esac

# used by httpdb
case $2 in
1)
	if [ "$brook_basic_enable" == "1" ];then
		restart_brook > $LOG_FILE
	else
		stop_brook > $LOG_FILE
	fi
	echo XU6J03M6 >> $LOG_FILE
	http_response $1
	;;
2)
	# remove all brook config in skipd
	echo_date 尝试关闭 brook... > $LOG_FILE
	sh $KSROOT/scripts/brook_config.sh stop
	echo_date 开始清理 brook 配置... >> $LOG_FILE
	confs=`dbus list brook | cut -d "=" -f 1 | grep -v "version"`
	for conf in $confs
	do
		echo_date 移除$conf >> $LOG_FILE
		dbus remove $conf
	done
	echo_date 设置一些默认参数... >> $LOG_FILE
	dbus set brook_basic_enable="0"
	echo_date 完成！ >> $LOG_FILE
	http_response $1
	;;
3)
	#备份ss配置
	echo "" > $LOG_FILE
	mkdir -p $KSROOT/webs/files
	dbus list brook | grep -v "status" | grep -v "enable" | grep -v "version" | sed 's/=/=\"/' | sed 's/$/\"/g'|sed 's/^/dbus set /' | sed '1 i\\n' | sed '1 isource /koolshare/scripts/base.sh' |sed '1 i#!/bin/sh' > $KSROOT/webs/files/brook_conf_backup.sh
	http_response "$1"
	echo XU6J03M6 >> $LOG_FILE
	;;
4)
	#用备份的brook_conf_backup.sh 去恢复配置
	echo_date "开始恢复brook配置..." > $LOG_FILE
	file_nu=`ls /tmp/upload/brook_conf_backup | wc -l`
	i=20
	until [ -n "$file_nu" ]
	do
	    i=$(($i-1))
	    if [ "$i" -lt 1 ];then
	        echo_date "错误：没有找到恢复文件!"
	        exit
	    fi
	    sleep 1
	done
	format=`cat /tmp/upload/brook_conf_backup.sh |grep dbus`
	if [ -n "format" ];then
		echo_date "检测到正确格式的配置文件！" >> $LOG_FILE
		cd /tmp/upload
		chmod +x brook_conf_backup.sh
		echo_date "恢复中..." >> $LOG_FILE
		sh brook_conf_backup.sh
		sleep 1
		rm -rf /tmp/upload/brook_conf_backup.sh
		echo_date "恢复完毕！" >> $LOG_FILE
	else
		echo_date "配置文件格式错误！" >> $LOG_FILE
	fi
	http_response "$1"
	echo XU6J03M6 >> $LOG_FILE
	;;
5)
	#打包brook插件
	check_update_brook > $LOG_FILE
	http_response "$1"
	;;
esac