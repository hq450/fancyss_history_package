#!/bin/sh

/koolshare/scripts/v2ray_config.sh > /tmp/upload/v2ray_log.txt &
